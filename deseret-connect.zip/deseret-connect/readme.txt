=== Plugin Name ===
Contributors: Deseret Digital Media
Tags: deseret connect
Requires at least: 3.0.1
Tested up to: 3.2.3
Stable tag: 1.0.1

Ingest posts from Deseret Connect

== Installation ==

1. Upload the contents of wp-deseret_connect.zip to your plugins directory.
2. Activate the plugin
3. Enter your API key in the "deseret_connect" menu on your admin panel.
4. Get the URL from your Deseret Connect rep to put in your admin panel.
